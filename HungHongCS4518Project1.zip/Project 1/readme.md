# CS4518 PROJECT 1
## Student Information
Name: Hung Hong
ID: hphong

## Overview of submission
This submission includes 2 separate folders for 2 parts of the project:
- Part 1 contains:
	- The cleaned version of PetWar in folder 'PetWar'
	- The debugged apk file
	- The webm that features the application made from Part 1 instruction
- Part 2 contains:
	- The cleaned version of PetWar in folder 'PetWar'
	- The debugged apk file
	- The webm that features the application made from UI redesign
	- 'Project_1_Part_2_Redesign_UI.md' which is the markdown tutorial on my implementation of Part 2
	- 'imgs' folder that contains images used for the markdown tutorial